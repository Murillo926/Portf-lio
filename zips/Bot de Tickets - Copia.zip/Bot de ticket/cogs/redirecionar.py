import discord
from discord.ext import commands
from discord import app_commands
from datetime import datetime, timezone, timedelta
from pymongo import MongoClient
import os
from dotenv import load_dotenv

load_dotenv()

ID_CATEGORIA_ROLE = 1392290257864626276
ID_CATEGORIA_REPORT = 1392290334242766908
ID_CATEGORIA_FANART = 1392290362906644551
ID_CATEGORIA_DOUBT = 1392290401850888192
ATENDENTE_TICKET = 1392289490248269885

UTC_MINUS_3 = timezone(timedelta(hours=-3))

MONGO_URI = os.getenv("MONGO_URI")
client = MongoClient(MONGO_URI)
db = client["economia_bot"]
claims_collection = db["ticket_claims"]

class Redirecionar(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(
        name="redirect",
        description="Redirects the service of this ticket to another agent."
    )
    @app_commands.describe(atendente="New attendant who will take over this ticket.")
    async def redirecionar(self, interaction: discord.Interaction, atendente: discord.Member):
        canal = interaction.channel

        categorias_ticket = [
            ID_CATEGORIA_ROLE,
            ID_CATEGORIA_REPORT,
            ID_CATEGORIA_FANART,
            ID_CATEGORIA_DOUBT
        ]
        if not isinstance(canal, discord.TextChannel) or canal.category_id not in categorias_ticket:
            return await interaction.response.send_message("❌ This command can only be used within a ticket channel.", ephemeral=True)

        cargo_treinador = interaction.guild.get_role(ATENDENTE_TICKET)

        if not cargo_treinador or cargo_treinador not in interaction.user.roles:
            return await interaction.response.send_message("❌ Only agents can redirect tickets.", ephemeral=True)

        if cargo_treinador not in atendente.roles:
            return await interaction.response.send_message("❌ The new person in charge does not have the position of attendant!", ephemeral=True)

        # 🔐 NOVA VERIFICAÇÃO: Confere se quem executa é o responsável atual
        claim = claims_collection.find_one({"ticket_id": canal.id})
        if claim and claim.get("responsavel_id") != interaction.user.id:
            return await interaction.response.send_message(
                "❌ Você não é o responsável atual por este ticket. Apenas o responsável pode redirecioná-lo.",
                ephemeral=True
            )

        await canal.set_permissions(interaction.user, overwrite=None)
        await canal.set_permissions(cargo_treinador, view_channel=False, send_messages=False)
        await canal.set_permissions(atendente, view_channel=True, send_messages=True)

        embed = discord.Embed(
            title="🔁 Redirected service",
            description=f"This ticket was redirected by {interaction.user.mention}.\n\n📌 New person in charge: {atendente.mention}",
            color=discord.Color.orange()
        )
        embed.set_footer(text=f"Redirected to {datetime.now(tz=UTC_MINUS_3).strftime('%d/%m/%Y %H:%M')}")
        await canal.send(embed=embed)

        claims_collection.update_one(
            {"ticket_id": canal.id},
            {"$set": {"responsavel_id": atendente.id}},
            upsert=True
        )

        await interaction.response.send_message("✅ Redirection successful!", ephemeral=True)

async def setup(bot):
    await bot.add_cog(Redirecionar(bot))
