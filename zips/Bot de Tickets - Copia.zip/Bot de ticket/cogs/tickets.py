import discord
from discord.ext import commands
from discord import app_commands
from discord.ui import View, Button, Modal, TextInput, Select
from pymongo import MongoClient
import os
from dotenv import load_dotenv
from datetime import datetime, timedelta, timezone
import asyncio
import html
import io
import json
import traceback

load_dotenv()

# IDs das categorias e cargos
ID_CATEGORIA_ROLE = 1392290257864626276
ID_CATEGORIA_REPORT = 1392290334242766908
ID_CATEGORIA_FANART = 1392290362906644551
ID_CATEGORIA_DOUBT = 1392290401850888192
ATENDENTE_TICKET = 1392289490248269885
ID_CANAL_LOGS = 1392288532277497987
BLACKLIST_ROLE_ID = 1392289371033571398
ADMIN_ROLE_2_ID = 1390309026444869663
ADMIN_ROLE_ID = 1390309110959968287
MOD_ROLE_ID = 1390308976658481264
HEAD_ADMIN_ROLE_ID = 1390309110959968287
HEAD_MOD_ROLE_ID = 1392571630550778027
DEV_ROLE_ID = 1391492420260073613

IMG_FINAL = "https://i.postimg.cc/3J2TjcLW/vox-seas-ticket.png"

MONGO_URI = os.getenv("MONGO_URI")
client = MongoClient(MONGO_URI)
db = client["economia_bot"]
claims_collection = db["ticket_claims"]
counters_collection = db["ticket_counters"]
open_tickets_collection = db["user_open_tickets"]
ticket_stats_collection = db["ticket_stats"]

FUSO_UTC_MINUS_3 = timezone(timedelta(hours=-3))

def formatar_duracao(inicio, fim):
    delta = fim - inicio
    dias = delta.days
    segundos = delta.seconds
    horas = segundos // 3600
    minutos = (segundos % 3600) // 60
    segundos = segundos % 60
    return f"{dias}d {horas}h {minutos}m {segundos}s"

def gerar_nome_ticket(tipo):
    doc = counters_collection.find_one_and_update(
        {"tipo": tipo},
        {"$inc": {"contador": 1}},
        upsert=True,
        return_document=True
    )
    numero = doc["contador"]
    return f"{tipo}-{numero:04d}"

def usuario_tem_ticket_aberto(user_id, tipo):
    return open_tickets_collection.find_one({"user_id": user_id, "tipo": tipo}) is not None

def registrar_ticket_aberto(user_id, canal_id, tipo):
    open_tickets_collection.insert_one({"user_id": user_id, "canal_id": canal_id, "tipo": tipo})

def remover_ticket_aberto(canal_id):
    open_tickets_collection.delete_one({"canal_id": canal_id})
    
def registrar_ticket_fechado(responsavel_id):
    ticket_stats_collection.update_one(
        {"user_id": responsavel_id},
        {"$inc": {"tickets_closed": 1}},
        upsert=True
    )

class TicketJaAbertoException(Exception):
    pass

class ConfirmFanartView(View):
    def __init__(self, bot, interaction, lang="en"):
        super().__init__(timeout=60)
        self.bot = bot
        self.interaction = interaction
        self.lang = lang
        self.value = None

    @discord.ui.button(label="Sim", style=discord.ButtonStyle.green)
    async def confirm(self, interaction: discord.Interaction, button: Button):
        await interaction.response.defer(ephemeral=True)
        self.value = True
        self.stop()
        await criar_ticket(self.interaction, "fanart", "Fanart submission", self.bot, responder=False, lang=self.lang)
        await interaction.followup.send("Ticket de fanart criado com sucesso!" if self.lang == "pt" else "Fanart ticket created successfully!", ephemeral=True)

    @discord.ui.button(label="Não", style=discord.ButtonStyle.red)
    async def cancel(self, interaction: discord.Interaction, button: Button):
        await interaction.response.defer(ephemeral=True)
        self.value = False
        self.stop()
        await interaction.followup.send("Ticket cancelado." if self.lang == "pt" else "Ticket cancelled.", ephemeral=True)

class FanartRulesView(View):
    def __init__(self, bot, lang="en"):
        super().__init__(timeout=None)
        self.bot = bot
        self.lang = lang
        self.claimed = False

    async def on_error(self, interaction: discord.Interaction, error: Exception, item) -> None:
        try:
            if not interaction.response.is_done():
                await interaction.response.defer(ephemeral=True)
        except:
            pass
        print(f"Erro na interação: {error}")

    @discord.ui.button(label="📕 Rules", style=discord.ButtonStyle.green, custom_id="rules_btn")
    async def show_rules(self, interaction: discord.Interaction, button: Button):
        try:
            await interaction.response.defer(ephemeral=True)
            
            desc = (
                "If you have created a fanart, you can submit it here.\n\n"
                "**Please note:** Your submission must follow all the guidelines below."
                " If it does not meet these guidelines, please close the ticket.\n\n"
                "✓ Must be your own artwork\n"
                "✓ Original content based on Roblox ONLY\n"
                "✓ Artwork must be safe for work (no NSFW/explicit content)\n"
                "✓ Must be quality work (no low-effort submissions)\n"
                "✓ Must be signed/watermarked to prevent theft\n\n"
                "If your art does not meet these requirements, please close the ticket."
            ) if self.lang == "en" else (
                "Se você criou uma fanart, pode enviá-la aqui.\n\n"
                "**Atenção:** Sua submissão deve seguir todas as diretrizes abaixo."
                " Se não atender a esses requisitos, feche o ticket.\n\n"
                "✓ Deve ser sua própria arte\n"
                "✓ Conteúdo original baseado APENAS em Roblox\n"
                "✓ Arte deve ser apropriada (sem conteúdo NSFW/explicito)\n"
                "✓ Deve ser um trabalho de qualidade (sem artes de baixo esforço)\n"
                "✓ Deve ter assinatura/marca d'água para evitar roubo\n\n"
                "Se sua arte não atender a esses requisitos, por favor feche o ticket."
            )
            embed = discord.Embed(
                title="🎨 Fanart Submission" if self.lang == "en" else "🎨 Submissão de Fanart",
                description=desc,
                color=discord.Color.blue()
            )
            await interaction.followup.send(embed=embed, ephemeral=True)
        except Exception as e:
            print(f"Erro no show_rules: {e}")

    @discord.ui.button(label="Close Ticket", style=discord.ButtonStyle.danger, emoji="🔒", custom_id="close_ticket_button")
    async def close_ticket(self, interaction: discord.Interaction, button: Button):
        try:
            await interaction.response.defer()

            canal = interaction.channel

            if not any(role.id in {ADMIN_ROLE_ID, ADMIN_ROLE_2_ID, ATENDENTE_TICKET, HEAD_MOD_ROLE_ID} for role in interaction.user.roles):
                return await interaction.followup.send("❌ Only the Support Team can close this ticket.", ephemeral=True)

            await canal.set_permissions(interaction.user, send_messages=False)

            mensagens = []
            async for msg in canal.history(limit=None, oldest_first=True):
                mensagens.append(msg)

            html_content = self.gerar_transcript_html(mensagens, canal.name)
            transcript_bytes = html_content.encode('utf-8')
            file_dm = discord.File(io.BytesIO(transcript_bytes), filename=f"{canal.name}.html")
            file_logs = discord.File(io.BytesIO(transcript_bytes), filename=f"{canal.name}.html")

            aberto = canal.created_at.replace(tzinfo=timezone.utc).astimezone(FUSO_UTC_MINUS_3)
            fechado = datetime.utcnow().replace(tzinfo=timezone.utc).astimezone(FUSO_UTC_MINUS_3)
            duracao = formatar_duracao(aberto, fechado)

            embed_log = discord.Embed(
                title="📝 Ticket Closed",
                description=f"**Channel:** `{canal.name}`\n**Opened by:** <@{canal.topic}>\n**Closed by:** {interaction.user.mention}",
                color=discord.Color.red()
            )
            embed_log.add_field(name="Opened at", value=aberto.strftime('%d/%m/%Y %H:%M'), inline=True)
            embed_log.add_field(name="Closed at", value=fechado.strftime('%d/%m/%Y %H:%M'), inline=True)
            embed_log.add_field(name="Duration", value=duracao, inline=False)
            embed_log.set_footer(text="Transcript attached 📄")

            try:
                if canal.topic:
                    user = await self.bot.fetch_user(int(canal.topic))
                    await user.send("📄 Here's your ticket transcript:", file=file_dm)
            except Exception as e:
                print(f"Erro ao enviar transcript: {e}")

            remover_ticket_aberto(canal.id)

            claim = claims_collection.find_one({"ticket_id": canal.id})
            if claim and claim.get("responsavel_id"):
                registrar_ticket_fechado(claim["responsavel_id"])

            canal_logs = interaction.guild.get_channel(ID_CANAL_LOGS)
            if canal_logs:
                try:
                    await canal_logs.send(embed=embed_log, file=file_logs)
                except Exception as e:
                    print(f"Erro ao enviar log: {e}")

            await interaction.followup.send("✅ Ticket closed successfully!", ephemeral=True)
            await asyncio.sleep(5)
            await canal.delete(reason=f"Ticket closed by {interaction.user}")

        except Exception as e:
            print(f"Erro no close_ticket: {e}")
            try:
                await interaction.followup.send("❌ An error occurred while closing the ticket.", ephemeral=True)
            except:
                pass
                
    @discord.ui.button(label="Claim", style=discord.ButtonStyle.primary, emoji="👨‍💼", custom_id="claim_ticket_button")
    async def claim_ticket(self, interaction: discord.Interaction, button: Button):
        canal = interaction.channel
        
        try:
            claim_existente = claims_collection.find_one({"ticket_id": canal.id})
            if claim_existente:
                responsavel_id = claim_existente.get("responsavel_id")
                if responsavel_id:
                    responsavel = interaction.guild.get_member(responsavel_id)
                    msg = f"❌ Este ticket já foi assumido por {responsavel.mention}." if responsavel else "❌ Este ticket já foi assumido."
                    return await interaction.response.send_message(msg, ephemeral=True)

                
            await interaction.response.defer(ephemeral=True)
            cargo_atendente = interaction.guild.get_role(ATENDENTE_TICKET)

            if not cargo_atendente or cargo_atendente not in interaction.user.roles:
                return await interaction.followup.send("❌ Only staff members can claim tickets.", ephemeral=True)

            claim_existente = claims_collection.find_one({"ticket_id": canal.id})
            if claim_existente:
                responsavel_id = claim_existente.get("responsavel_id")
                responsavel = interaction.guild.get_member(responsavel_id)
                msg = f"❌ Este ticket já foi assumido por {responsavel.mention}." if responsavel else "❌ Este ticket já foi assumido."
                return await interaction.followup.send(msg, ephemeral=True)

            self.claimed = False
            
            # Remover permissões do cargo de atendente primeiro
            await canal.set_permissions(cargo_atendente, overwrite=None)
            
            # Conceder permissões apenas ao reivindicador
            await canal.set_permissions(
                interaction.user,
                view_channel=True,
                send_messages=True,
                read_message_history=True
            )

            claims_collection.update_one(
                {"ticket_id": canal.id},
                {"$set": {"responsavel_id": interaction.user.id, "data": datetime.utcnow()}},
                upsert=True
            )

            embed = discord.Embed(
                title="Ticket Claimed",
                description=f"This ticket has been claimed by {interaction.user.mention}.",
                color=discord.Color.blue()
            )
            await canal.send(embed=embed)
            await interaction.followup.send("✅ Ticket claimed successfully!", ephemeral=True)
            
        except Exception as e:
            print(f"Erro no claim_ticket: {e}")
            await interaction.followup.send("❌ An error occurred while claiming the ticket.", ephemeral=True)

    def gerar_transcript_html(self, mensagens, nome_canal):
        html_content = f"""
        <!DOCTYPE html><html lang='en'><head><meta charset='UTF-8'><title>Transcript - {html.escape(nome_canal)}</title>
        <style>
            body {{ background-color: #2C2F33; color: #FFF; font-family: Arial, sans-serif; padding: 20px; }}
            .msg {{ background-color: #23272A; padding: 10px; border-radius: 5px; margin-bottom: 10px; }}
            .author {{ font-weight: bold; color: #00B0F4; }}
            .timestamp {{ color: #999; font-size: 0.9em; margin-left: 10px; }}
            .content {{ margin-top: 5px; white-space: pre-wrap; }}
            .attachment {{ margin-top: 5px; color: #7289DA; }}
            .system {{ color: #43B581; }}
        </style></head><body><h1>Transcript - {html.escape(nome_canal)}</h1>
        """
        
        for msg in mensagens:
            autor = html.escape(msg.author.display_name)
            data = msg.created_at.strftime('%d/%m/%Y %H:%M')
            conteudo = html.escape(msg.content).replace('\n', '<br>') if msg.content else ""
            
            html_content += f"""
            <div class='msg'>
                <div><span class='author'>{autor}</span><span class='timestamp'>{data}</span></div>
                <div class='content'>{conteudo}</div>
            """
            
            if msg.attachments:
                for attachment in msg.attachments:
                    html_content += f"""<div class='attachment'>📎 Attachment: <a href="{attachment.url}" target="_blank">{attachment.filename}</a></div>"""
            
            if msg.embeds:
                html_content += """<div class='attachment'>📊 Embed (content not displayed in transcript)</div>"""
            
            html_content += "</div>"
        
        html_content += "</body></html>"
        return html_content

class TicketButtonsView(View):
    def __init__(self, bot):
        super().__init__(timeout=None)
        self.bot = bot
        self.claimed = False

    async def on_error(self, interaction: discord.Interaction, error: Exception, item) -> None:
        try:
            if not interaction.response.is_done():
                await interaction.response.defer(ephemeral=True)
        except:
            pass
        print(f"Erro na interação: {error}")

    @discord.ui.button(label="Close Ticket", style=discord.ButtonStyle.danger, emoji="🔒", custom_id="close_ticket_button")
    async def close_ticket(self, interaction: discord.Interaction, button: Button):
        try:
            await interaction.response.defer()

            canal = interaction.channel

            if not any(role.id in {ADMIN_ROLE_ID, ADMIN_ROLE_2_ID, ATENDENTE_TICKET, HEAD_MOD_ROLE_ID} for role in interaction.user.roles):
                return await interaction.followup.send("❌ Only the Support Team can close this ticket.", ephemeral=True)

            await canal.set_permissions(interaction.user, send_messages=False)

            mensagens = []
            async for msg in canal.history(limit=None, oldest_first=True):
                mensagens.append(msg)

            html_content = self.gerar_transcript_html(mensagens, canal.name)
            transcript_bytes = html_content.encode('utf-8')
            file_dm = discord.File(io.BytesIO(transcript_bytes), filename=f"{canal.name}.html")
            file_logs = discord.File(io.BytesIO(transcript_bytes), filename=f"{canal.name}.html")

            aberto = canal.created_at.replace(tzinfo=timezone.utc).astimezone(FUSO_UTC_MINUS_3)
            fechado = datetime.utcnow().replace(tzinfo=timezone.utc).astimezone(FUSO_UTC_MINUS_3)
            duracao = formatar_duracao(aberto, fechado)

            embed_log = discord.Embed(
                title="📝 Ticket Closed",
                description=f"**Channel:** `{canal.name}`\n**Opened by:** <@{canal.topic}>\n**Closed by:** {interaction.user.mention}",
                color=discord.Color.red()
            )
            embed_log.add_field(name="Opened at", value=aberto.strftime('%d/%m/%Y %H:%M'), inline=True)
            embed_log.add_field(name="Closed at", value=fechado.strftime('%d/%m/%Y %H:%M'), inline=True)
            embed_log.add_field(name="Duration", value=duracao, inline=False)
            embed_log.set_footer(text="Transcript attached 📄")

            try:
                if canal.topic:
                    user = await self.bot.fetch_user(int(canal.topic))
                    await user.send("📄 Here's your ticket transcript:", file=file_dm)
            except Exception as e:
                print(f"Erro ao enviar transcript: {e}")

            remover_ticket_aberto(canal.id)

            claim = claims_collection.find_one({"ticket_id": canal.id})
            if claim and claim.get("responsavel_id"):
                registrar_ticket_fechado(claim["responsavel_id"])

            canal_logs = interaction.guild.get_channel(ID_CANAL_LOGS)
            if canal_logs:
                try:
                    await canal_logs.send(embed=embed_log, file=file_logs)
                except Exception as e:
                    print(f"Erro ao enviar log: {e}")

            await interaction.followup.send("✅ Ticket closed successfully!", ephemeral=True)
            await asyncio.sleep(5)
            await canal.delete(reason=f"Ticket closed by {interaction.user}")

        except Exception as e:
            print(f"Erro no close_ticket: {e}")
            try:
                await interaction.followup.send("❌ An error occurred while closing the ticket.", ephemeral=True)
            except:
                pass

    @discord.ui.button(label="Claim", style=discord.ButtonStyle.primary, emoji="👨‍💼", custom_id="claim_ticket_button")
    async def claim_ticket(self, interaction: discord.Interaction, button: Button):
        canal = interaction.channel

        try:
            claim_existente = claims_collection.find_one({"ticket_id": canal.id})
            if claim_existente:
                responsavel_id = claim_existente.get("responsavel_id")
                if responsavel_id:
                    responsavel = interaction.guild.get_member(responsavel_id)
                    msg = f"❌ Este ticket já foi assumido por {responsavel.mention}." if responsavel else "❌ Este ticket já foi assumido."
                    return await interaction.response.send_message(msg, ephemeral=True)
                
            await interaction.response.defer(ephemeral=True)
            cargo_atendente = interaction.guild.get_role(ATENDENTE_TICKET)

            if not cargo_atendente or cargo_atendente not in interaction.user.roles:
                return await interaction.followup.send("❌ Only staff members can claim tickets.", ephemeral=True)

            claim_existente = claims_collection.find_one({"ticket_id": canal.id})
            if claim_existente:
                responsavel_id = claim_existente.get("responsavel_id")
                responsavel = interaction.guild.get_member(responsavel_id)
                msg = f"❌ Este ticket já foi assumido por {responsavel.mention}." if responsavel else "❌ Este ticket já foi assumido."
                return await interaction.followup.send(msg, ephemeral=True)

            self.claimed = False
            
            # Remover permissões do cargo de atendente primeiro
            await canal.set_permissions(cargo_atendente, overwrite=None)
            
            # Conceder permissões apenas ao reivindicador
            await canal.set_permissions(
                interaction.user,
                view_channel=True,
                send_messages=True,
                read_message_history=True
            )

            claims_collection.update_one(
                {"ticket_id": canal.id},
                {"$set": {"responsavel_id": interaction.user.id, "data": datetime.utcnow()}},
                upsert=True
            )

            embed = discord.Embed(
                title="Ticket Claimed",
                description=f"This ticket has been claimed by {interaction.user.mention}.",
                color=discord.Color.blue()
            )
            await canal.send(embed=embed)
            await interaction.followup.send("✅ Ticket claimed successfully!", ephemeral=True)
            
        except Exception as e:
            print(f"Erro no claim_ticket: {e}")
            await interaction.followup.send("❌ An error occurred while claiming the ticket.", ephemeral=True)

    def gerar_transcript_html(self, mensagens, nome_canal):
        html_content = f"""
        <!DOCTYPE html><html lang='en'><head><meta charset='UTF-8'><title>Transcript - {html.escape(nome_canal)}</title>
        <style>
            body {{ background-color: #2C2F33; color: #FFF; font-family: Arial, sans-serif; padding: 20px; }}
            .msg {{ background-color: #23272A; padding: 10px; border-radius: 5px; margin-bottom: 10px; }}
            .author {{ font-weight: bold; color: #00B0F4; }}
            .timestamp {{ color: #999; font-size: 0.9em; margin-left: 10px; }}
            .content {{ margin-top: 5px; white-space: pre-wrap; }}
            .attachment {{ margin-top: 5px; color: #7289DA; }}
            .system {{ color: #43B581; }}
        </style></head><body><h1>Transcript - {html.escape(nome_canal)}</h1>
        """
        
        for msg in mensagens:
            autor = html.escape(msg.author.display_name)
            data = msg.created_at.strftime('%d/%m/%Y %H:%M')
            conteudo = html.escape(msg.content).replace('\n', '<br>') if msg.content else ""
            
            html_content += f"""
            <div class='msg'>
                <div><span class='author'>{autor}</span><span class='timestamp'>{data}</span></div>
                <div class='content'>{conteudo}</div>
            """
            
            if msg.attachments:
                for attachment in msg.attachments:
                    html_content += f"""<div class='attachment'>📎 Attachment: <a href="{attachment.url}" target="_blank">{attachment.filename}</a></div>"""
            
            if msg.embeds:
                html_content += """<div class='attachment'>📊 Embed (content not displayed in transcript)</div>"""
            
            html_content += "</div>"
        
        html_content += "</body></html>"
        return html_content

class TicketAdmin(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="unclaim", description="Remove your claim from the current ticket.")
    async def unclaim(self, interaction: discord.Interaction):
        canal = interaction.channel
        cargo_treinador = interaction.guild.get_role(ATENDENTE_TICKET)

        categorias_validas = [
            ID_CATEGORIA_ROLE,
            ID_CATEGORIA_REPORT,
            ID_CATEGORIA_FANART,
            ID_CATEGORIA_DOUBT
        ]
        if not isinstance(canal, discord.TextChannel) or canal.category_id not in categorias_validas:
            return await interaction.response.send_message("❌ This command can only be used in a ticket channel.", ephemeral=True)

        claim = claims_collection.find_one({"ticket_id": canal.id})
        if not claim or claim.get("responsavel_id") != interaction.user.id:
            return await interaction.response.send_message("❌ You are not the current responsible for this ticket.", ephemeral=True)

        await canal.set_permissions(interaction.user, overwrite=None)
        await canal.set_permissions(cargo_treinador, overwrite=discord.PermissionOverwrite(view_channel=True, send_messages=True))

        claims_collection.delete_one({"ticket_id": canal.id})

        embed = discord.Embed(
            title="🔓 Ticket Released",
            description=f"{interaction.user.mention} released this ticket. Now any staff member can reclaim it.",
            color=discord.Color.yellow()
        )
        await canal.send(embed=embed)
        await interaction.response.send_message("✅ You have released the ticket.", ephemeral=True)

    @app_commands.command(name="close", description="Close the current ticket")
    async def close_ticket(self, interaction: discord.Interaction):
        try:
            await interaction.response.defer()

            canal = interaction.channel

            if not any(role.id in {ADMIN_ROLE_ID, ADMIN_ROLE_2_ID, ATENDENTE_TICKET, HEAD_MOD_ROLE_ID} for role in interaction.user.roles):
                return await interaction.followup.send("❌ Only the Support Team can close this ticket.", ephemeral=True)

            await canal.set_permissions(interaction.user, send_messages=False)

            mensagens = []
            async for msg in canal.history(limit=None, oldest_first=True):
                mensagens.append(msg)

            html_content = TicketButtonsView(self.bot).gerar_transcript_html(mensagens, canal.name)
            transcript_bytes = html_content.encode('utf-8')
            file_dm = discord.File(io.BytesIO(transcript_bytes), filename=f"{canal.name}.html")
            file_logs = discord.File(io.BytesIO(transcript_bytes), filename=f"{canal.name}.html")

            aberto = canal.created_at.replace(tzinfo=timezone.utc).astimezone(FUSO_UTC_MINUS_3)
            fechado = datetime.utcnow().replace(tzinfo=timezone.utc).astimezone(FUSO_UTC_MINUS_3)
            duracao = formatar_duracao(aberto, fechado)

            embed_log = discord.Embed(
                title="📝 Ticket Closed",
                description=f"**Channel:** `{canal.name}`\n**Opened by:** <@{canal.topic}>\n**Closed by:** {interaction.user.mention}",
                color=discord.Color.red()
            )
            embed_log.add_field(name="Opened at", value=aberto.strftime('%d/%m/%Y %H:%M'), inline=True)
            embed_log.add_field(name="Closed at", value=fechado.strftime('%d/%m/%Y %H:%M'), inline=True)
            embed_log.add_field(name="Duration", value=duracao, inline=False)
            embed_log.set_footer(text="Transcript attached 📄")

            try:
                if canal.topic:
                    user = await self.bot.fetch_user(int(canal.topic))
                    await user.send("📄 Here's your ticket transcript:", file=file_dm)
            except Exception as e:
                print(f"Erro ao enviar transcript: {e}")

            remover_ticket_aberto(canal.id)

            claim = claims_collection.find_one({"ticket_id": canal.id})
            if claim and claim.get("responsavel_id"):
                registrar_ticket_fechado(claim["responsavel_id"])

            canal_logs = interaction.guild.get_channel(ID_CANAL_LOGS)
            if canal_logs:
                try:
                    await canal_logs.send(embed=embed_log, file=file_logs)
                except Exception as e:
                    print(f"Erro ao enviar log: {e}")

            await interaction.followup.send("✅ Ticket closed successfully!", ephemeral=True)
            await asyncio.sleep(5)
            await canal.delete(reason=f"Ticket closed by {interaction.user}")

        except Exception as e:
            print(f"Erro no close_ticket: {e}")
            try:
                await interaction.followup.send("❌ An error occurred while closing the ticket.", ephemeral=True)
            except:
                pass

    def gerar_transcript_html(self, mensagens, nome_canal):
        html_content = f"""
        <!DOCTYPE html><html lang='en'><head><meta charset='UTF-8'><title>Transcript - {html.escape(nome_canal)}</title>
        <style>
            body {{ background-color: #2C2F33; color: #FFF; font-family: Arial, sans-serif; padding: 20px; }}
            .msg {{ background-color: #23272A; padding: 10px; border-radius: 5px; margin-bottom: 10px; }}
            .author {{ font-weight: bold; color: #00B0F4; }}
            .timestamp {{ color: #999; font-size: 0.9em; margin-left: 10px; }}
            .content {{ margin-top: 5px; white-space: pre-wrap; }}
            .attachment {{ margin-top: 5px; color: #7289DA; }}
            .system {{ color: #43B581; }}
        </style></head><body><h1>Transcript - {html.escape(nome_canal)}</h1>
        """
        
        for msg in mensagens:
            autor = html.escape(msg.author.display_name)
            data = msg.created_at.strftime('%d/%m/%Y %H:%M')
            conteudo = html.escape(msg.content).replace('\n', '<br>') if msg.content else ""
            
            html_content += f"""
            <div class='msg'>
                <div><span class='author'>{autor}</span><span class='timestamp'>{data}</span></div>
                <div class='content'>{conteudo}</div>
            """
            
            if msg.attachments:
                for attachment in msg.attachments:
                    html_content += f"""<div class='attachment'>📎 Attachment: <a href="{attachment.url}" target="_blank">{attachment.filename}</a></div>"""
            
            if msg.embeds:
                html_content += """<div class='attachment'>📊 Embed (content not displayed in transcript)</div>"""
            
            html_content += "</div>"
        
        html_content += "</body></html>"
        return html_content

    @app_commands.command(name="adicionar", description="Adiciona um membro ao ticket atual.")
    @app_commands.describe(usuario="Membro que você deseja adicionar ao ticket.")
    async def adicionar(self, interaction: discord.Interaction, usuario: discord.Member):
        canal = interaction.channel
        if not isinstance(canal, discord.TextChannel):
            return await interaction.response.send_message("❌ Este comando só pode ser usado em um canal de texto.", ephemeral=True)

        await canal.set_permissions(usuario, view_channel=True, send_messages=True, read_message_history=True)
        await interaction.response.send_message(f"✅ {usuario.mention} foi adicionado ao ticket.", ephemeral=True)

    @app_commands.command(name="unclaim_adm", description="(ADMIN_ROLE_2) Libera o ticket mesmo que você não seja o responsável.")
    async def unclaim_adm(self, interaction: discord.Interaction):
        if not any(role.id == ADMIN_ROLE_2_ID for role in interaction.user.roles):
            return await interaction.response.send_message("❌ Você não tem permissão para usar este comando.", ephemeral=True)

        canal = interaction.channel
        if not isinstance(canal, discord.TextChannel):
            return await interaction.response.send_message("❌ Este comando só pode ser usado em um canal de ticket.", ephemeral=True)

        claim = claims_collection.find_one({"ticket_id": canal.id})
        if not claim or not claim.get("responsavel_id"):
            return await interaction.response.send_message("❌ Este ticket não está atualmente com ninguém.", ephemeral=True)

        membro = interaction.guild.get_member(claim["responsavel_id"])
        if membro:
            await canal.set_permissions(membro, overwrite=None)

        cargo_atendente = interaction.guild.get_role(ATENDENTE_TICKET)
        if cargo_atendente:
            await canal.set_permissions(cargo_atendente, overwrite=discord.PermissionOverwrite(view_channel=True, send_messages=True))

        claims_collection.delete_one({"ticket_id": canal.id})

        embed = discord.Embed(
            title="🔓 Ticket Liberado por Admin",
            description=f"O ticket foi liberado por {interaction.user.mention}. Agora qualquer atendente pode reassumir.",
            color=discord.Color.orange()
        )
        await canal.send(embed=embed)
        await interaction.response.send_message("✅ Ticket liberado com sucesso.", ephemeral=True)

    @app_commands.command(name="rank", description="Mostra o ranking de atendentes.")
    async def ticket_stats(self, interaction: discord.Interaction):
        if not any(role.id == ATENDENTE_TICKET for role in interaction.user.roles):
            return await interaction.response.send_message("❌ Apenas Atendentes de Tickets podem usar este comando.", ephemeral=True)

        pipeline = [
            {"$group": {
                "_id": "$responsavel_id",
                "total_claims": {"$sum": 1},
                "last_claim": {"$max": "$data"}
            }},
            {"$sort": {"total_claims": -1}},
            {"$limit": 10}
        ]

        top_claimers = list(claims_collection.aggregate(pipeline))
        embed = discord.Embed(
            title="🏆 Top Atendentes por Tickets Assumidos",
            color=discord.Color.gold()
        )

        if not top_claimers:
            embed.description = "Nenhum ticket assumido ainda."
            return await interaction.response.send_message(embed=embed)

        stats_list = []
        for i, claimer in enumerate(top_claimers, 1):
            try:
                user = await self.bot.fetch_user(claimer["_id"])
                last_claim = claimer["last_claim"].strftime('%d/%m/%Y') if claimer.get("last_claim") else "Nunca"
                stats_list.append(
                    f"**{i}.** {user.mention} - `{claimer['total_claims']}` tickets (Último: {last_claim})"
                )
            except Exception as e:
                print(f"Erro ao buscar usuário {claimer['_id']}: {e}")
                continue

        embed.description = "\n".join(stats_list)
        embed.set_footer(text="Baseado nos dados dos tickets assumidos.")
        await interaction.response.send_message(embed=embed)
        
        
class RoleModal(Modal):
    def __init__(self, bot, lang="en"):
        super().__init__(title="Ticket de Cargo" if lang == "pt" else "Role Ticket")
        self.bot = bot
        self.lang = lang
        self.cargo = TextInput(
            label="Qual cargo deseja?" if lang == "pt" else "Which role do you want?",
            style=discord.TextStyle.short,
            custom_id="role_input"
        )
        self.add_item(self.cargo)

    async def on_submit(self, interaction: discord.Interaction):
        try:
            await interaction.response.defer(ephemeral=True)
            canal = await criar_ticket(
                interaction=interaction,
                tipo="role",
                descricao=f"**Cargo desejado:** {self.cargo.value}" if self.lang == "pt" else f"**Requested Role:** {self.cargo.value}",
                bot=self.bot,
                lang=self.lang,
                responder=False
            )
            await interaction.followup.send(
                f"✅ Ticket criado com sucesso! Vá para {canal.mention}." if self.lang == "pt" else f"✅ Ticket successfully created! Go to {canal.mention}.",
                ephemeral=True
            )
        except Exception as e:
            print("Erro no Modal:", e)
            await interaction.followup.send(
                "❌ Ocorreu um erro ao criar o ticket." if self.lang == "pt" else "��� An error occurred while creating the ticket.",
                ephemeral=True
            )

class ReportModal(Modal):
    def __init__(self, bot, lang="en"):
        super().__init__(title="Ticket de Denúncia" if lang == "pt" else "Report Ticket")
        self.bot = bot
        self.lang = lang
        self.user = TextInput(
            label="Informe o ID do usuário" if lang == "pt" else "User ID",
            style=discord.TextStyle.short,
            custom_id="report_user"
        )
        self.motivo = TextInput(
            label="Motivo e envie print" if lang == "pt" else "Reason",
            style=discord.TextStyle.long,
            custom_id="report_motivo"
        )
        self.add_item(self.user)
        self.add_item(self.motivo)

    async def on_submit(self, interaction: discord.Interaction):
        try:
            await interaction.response.defer(ephemeral=True)
            motivo = f"**ID do Reportado:** {self.user.value}\n**Motivo:** {self.motivo.value}" if self.lang == "pt" else f"**Reported ID:** {self.user.value}\n**Reason:** {self.motivo.value}"
            canal = await criar_ticket(
                interaction=interaction,
                tipo="report",
                descricao=motivo,
                bot=self.bot,
                lang=self.lang,
                responder=False
            )
            await interaction.followup.send(
                f"✅ Ticket criado com sucesso! Vá para {canal.mention}." if self.lang == "pt" else f"✅ Ticket successfully created! Go to {canal.mention}.",
                ephemeral=True
            )
        except Exception as e:
            print("Erro no Modal:", e)
            await interaction.followup.send(
                "❌ Ocorreu um erro ao criar o ticket." if self.lang == "pt" else "❌ An error occurred while creating the ticket.",
                ephemeral=True
            )

class DoubtModal(Modal):
    def __init__(self, bot, lang="en"):
        super().__init__(title="Ticket de Dúvida" if lang == "pt" else "Doubt Ticket")
        self.bot = bot
        self.lang = lang
        self.pergunta = TextInput(
            label="Qual é sua dúvida?" if lang == "pt" else "What is your question?",
            style=discord.TextStyle.long,
            custom_id="doubt_input"
        )
        self.add_item(self.pergunta)

    async def on_submit(self, interaction: discord.Interaction):
        try:
            await interaction.response.defer(ephemeral=True)
            texto = f"**Dúvida informada:** {self.pergunta.value}" if self.lang == "pt" else f"**Question:** {self.pergunta.value}"
            canal = await criar_ticket(
                interaction=interaction,
                tipo="doubt",
                descricao=texto,
                bot=self.bot,
                lang=self.lang,
                responder=False
            )
            await interaction.followup.send(
                f"✅ Ticket criado com sucesso! Vá para {canal.mention}." if self.lang == "pt" else f"✅ Ticket successfully created! Go to {canal.mention}.",
                ephemeral=True
            )
        except Exception as e:
            print("Erro no Modal:", e)
            await interaction.followup.send(
                "❌ Ocorreu um erro ao criar o ticket." if self.lang == "pt" else "❌ An error occurred while creating the ticket.",
                ephemeral=True
            )
            

async def criar_ticket(interaction, tipo, descricao, bot, responder=True, lang="en"):
    try:
        if any(role.id == BLACKLIST_ROLE_ID for role in interaction.user.roles):
            msg = (
                "🚫 Você não pode abrir um ticket porque está com o cargo `Blacklist`."
                if lang == "pt"
                else "🚫 You can't open a ticket because you have the `Blacklist` role."
            )
            await interaction.response.send_message(msg, ephemeral=True)
            return

        if not hasattr(bot, "_tickets_em_aberto"):
            bot._tickets_em_aberto = set()
        if interaction.user.id in bot._tickets_em_aberto:
            await interaction.response.send_message(
                "⏳ Você já está criando um ticket." if lang == "pt" else "⏳ You are already creating a ticket.",
                ephemeral=True
            )
            return
        bot._tickets_em_aberto.add(interaction.user.id)

        if usuario_tem_ticket_aberto(interaction.user.id, tipo):
            await interaction.response.send_message(
                "⚠️ Você já possui um ticket desse tipo aberto." if lang == "pt" else "⚠️ You already have an open ticket of this type.",
                ephemeral=True
            )
            return

        categoria_ids = {
            "role": ID_CATEGORIA_ROLE,
            "report": ID_CATEGORIA_REPORT,
            "fanart": ID_CATEGORIA_FANART,
            "doubt": ID_CATEGORIA_DOUBT
        }
        categoria = interaction.guild.get_channel(categoria_ids[tipo])
        nome_ticket = gerar_nome_ticket(tipo)

        canal = await interaction.guild.create_text_channel(
            name=nome_ticket,
            category=categoria,
            topic=str(interaction.user.id)
        )

        await canal.set_permissions(interaction.guild.default_role, view_channel=False)
        await canal.set_permissions(interaction.user, view_channel=True)
        for rid in [ATENDENTE_TICKET, ADMIN_ROLE_ID, ADMIN_ROLE_2_ID]:
            role = interaction.guild.get_role(rid)
            if role:
                await canal.set_permissions(role, view_channel=True)

        equipe = interaction.guild.get_role(ATENDENTE_TICKET)
        saudacao = (
            "Olá {0}! Aguarde que logo logo a equipe de suporte irá lhe atender."
            if lang == "pt" else
            "Hello {0}! Please wait, our support team will assist you soon."
        )
        await canal.send(saudacao.format(interaction.user.mention))

        titulos = {
            "pt": {
                "role": "Pedido de Cargo",
                "report": "Reporte de Usuário",
                "fanart": "Envio de Fan-art",
                "doubt": "Pedido de Suporte"
            },
            "en": {
                "role": "Role Request",
                "report": "User Report",
                "fanart": "Fan-art Submission",
                "doubt": "Support Request"
            }
        }
        titulo = titulos[lang][tipo]
        embed = discord.Embed(
            title=titulo,
            description=(f"**Aberto por:** {interaction.user.mention}\n{descricao}" if lang == "pt"
                         else f"**Opened by:** {interaction.user.mention}\n{descricao}"),
            color=discord.Color.green()
        )
        embed.set_image(url=IMG_FINAL)

        if tipo == "fanart":
            await canal.send(embed=embed, view=FanartRulesView(bot, lang=lang))
        else:
            await canal.send(embed=embed, view=TicketButtonsView(bot))

        registrar_ticket_aberto(interaction.user.id, canal.id, tipo)

        return canal

    except Exception as e:
        print("Erro ao criar ticket:", e)
        if not interaction.response.is_done():
            await interaction.response.send_message(
                "❌ Ocorreu um erro ao criar o ticket." if lang == "pt"
                else "❌ An error occurred while creating the ticket.",
                ephemeral=True
            )
    finally:
        bot._tickets_em_aberto.discard(interaction.user.id)

class TicketPanelView(View):
    def __init__(self, bot, lang="en"):
        super().__init__(timeout=None)
        self.bot = bot
        self.lang = lang
        self.select_menu = self.build_select(self.lang)
        self.add_item(self.select_menu)
        self.add_lang_buttons()

    def add_lang_buttons(self):
        btn_pt = Button(
            label="Portuguese",
            emoji="🇧🇷",
            style=discord.ButtonStyle.primary,
            custom_id="lang_pt"
        )
        btn_pt.callback = self.send_portuguese_embed
        self.add_item(btn_pt)

    def build_select(self, lang):
        options = {
            "en": [
                discord.SelectOption(label="👤 Role", value="role"),
                discord.SelectOption(label="🚫 Report", value="report"),
                discord.SelectOption(label="🎨 Fan-art", value="fanart"),
                discord.SelectOption(label="❓ Doubt", value="doubt"),
            ],
            "pt": [
                discord.SelectOption(label="👤 Cargo", value="role"),
                discord.SelectOption(label="🚫 Denúncia", value="report"),
                discord.SelectOption(label="🎨 Fan-art", value="fanart"),
                discord.SelectOption(label="❓ Dúvida", value="doubt"),
            ]
        }
        select = Select(
            placeholder="Choose the ticket type" if lang == "en" else "Escolha o tipo de ticket",
            custom_id="painel_ticket_select",
            options=options[lang]
        )
        select.callback = self.select
        return select

    async def select(self, interaction):
        value = self.select_menu.values[0]

        if value == "role":
            await interaction.response.send_modal(RoleModal(self.bot, lang=self.lang))
        elif value == "report":
            await interaction.response.send_modal(ReportModal(self.bot, lang=self.lang))
        elif value == "fanart":
            await interaction.response.defer(ephemeral=True)
            view = ConfirmFanartView(self.bot, interaction, lang=self.lang)
            await interaction.followup.send(
                "Do you really want to open a fanart ticket?" if self.lang == "en" else "Você realmente deseja abrir um ticket de fanart?",
                view=view,
                ephemeral=True
            )
        elif value == "doubt":
            await interaction.response.send_modal(DoubtModal(self.bot, lang=self.lang))

    async def send_portuguese_embed(self, interaction: discord.Interaction):
        embed = discord.Embed(
            title="Central de Tickets",
            description="Selecione o tipo de ticket que deseja abrir.\nEscolher a categoria correta nos ajuda a atendê-lo com mais eficiência.",
            color=discord.Color.blue()
        )
        embed.set_image(url=IMG_FINAL)
        view = TicketPanelView(self.bot, lang="pt")
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)

class TicketSystem(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="ticket_panel", description="Ticket panel")
    async def painel_tickets(self, interaction):
        if not any(role.id == ADMIN_ROLE_2_ID for role in interaction.user.roles):
            await interaction.response.send_message("❌ You don't have permission.", ephemeral=True)
            return

        embed = discord.Embed(
            title="Ticket Center",
            description="Select the type of ticket you wish to open.\nChoosing the correct category helps us assist you more efficiently.",
            color=discord.Color.blue()
        )
        embed.set_image(url=IMG_FINAL)
        await interaction.response.send_message(embed=embed, view=TicketPanelView(self.bot))

async def setup(bot):
    await bot.add_cog(TicketSystem(bot))
    bot.add_view(TicketPanelView(bot))
    await bot.add_cog(TicketAdmin(bot))