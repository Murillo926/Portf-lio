import discord
from discord.ext import commands
from discord import app_commands
from datetime import datetime, timedelta
from pymongo import MongoClient
import os
from dotenv import load_dotenv

load_dotenv()
MONGO_URI = os.getenv("MONGO_URI")
client = MongoClient(MONGO_URI)
db = client["economia_bot"]
claims_collection = db["ticket_claims"]  


ADMIN_ROLE_ID = 1390309026444869663
HEAD_ADMIN_ROLE_ID = 1390309110959968287
HEAD_MOD_ROLE_ID = 1392571630550778027
ATENDENTE_TICKET = 1392289490248269885

class TicketsAtendidos(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="ticket_completed", description="Check how many tickets were handled by a staff member in a given period.")
    @app_commands.describe(membro="Staff to be consulted", dias="Number of days to consider (default: 7)")
    async def tickets_atendidos(self, interaction: discord.Interaction, membro: discord.Member, dias: int = 7):

        cargos_permitidos = [ADMIN_ROLE_ID, HEAD_ADMIN_ROLE_ID, HEAD_MOD_ROLE_ID,]
        if not any(role.id in cargos_permitidos for role in interaction.user.roles):
            await interaction.response.send_message("❌ You are not allowed.", ephemeral=True)
            return

        if ATENDENTE_TICKET not in [role.id for role in membro.roles]:
            return await interaction.response.send_message(
                f"❌ User {membro.mention} not a staff.",
                ephemeral=True
            )

        await interaction.response.defer()

        data_limite = datetime.utcnow() - timedelta(days=dias)
        filtro = {
            "responsavel_id": membro.id,
            "data": {"$gte": data_limite}
        }

        registros = list(claims_collection.find(filtro))
        total = len(registros)

        if total == 0:
            return await interaction.followup.send(f"⚠️ No tickets answered by {membro.mention} in the last {dias} days.", ephemeral=True)

        embed = discord.Embed(
            title=f"Tickets Completed - {membro.display_name}",
            color=discord.Color.green()
        )
        embed.set_thumbnail(url=membro.display_avatar.url)
        embed.add_field(name="📅 Radius of days", value=f"{dias} days", inline=True)
        embed.add_field(name="✅ Tickets Completed", value=f"{total}", inline=True)
        embed.set_footer(text=f"Requested by: {interaction.user.display_name}", icon_url=interaction.user.display_avatar.url)
        embed.timestamp = discord.utils.utcnow()

        await interaction.followup.send(embed=embed)

async def setup(bot):
    await bot.add_cog(TicketsAtendidos(bot))