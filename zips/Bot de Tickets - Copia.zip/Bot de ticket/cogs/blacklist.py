import discord
from discord.ext import commands, tasks
from discord import app_commands
from datetime import datetime, timedelta, timezone
import asyncio


from pymongo import MongoClient
import os

MONGO_URI = os.getenv("MONGO_URI")
mongo_client = MongoClient(MONGO_URI)
db = mongo_client["seu_db"]
collection = db["blacklist"]


ADMIN_ROLE_ID = 1390309026444869663
MOD_ROLE_ID = 1390308976658481264
HEAD_ADMIN_ROLE_ID = 1390309110959968287
HEAD_MOD_ROLE_ID = 1392571630550778027
DEV_ROLE_ID = 1391492420260073613

BLACKLIST_ROLE_ID = 1392289371033571398
UTC_MINUS_3 = timezone(timedelta(hours=-3))


class Blacklist(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.check_blacklist_expirations.start()

    def cog_unload(self):
        self.check_blacklist_expirations.cancel()

    @app_commands.command(name="blacklist_add", description="Add a user to the blacklist.")
    @app_commands.describe(
        user="User to add",
        duration_minutes="Duration in minutes (optional, leave blank for unlimited)"
    )
    async def blacklist_add(
        self,
        interaction: discord.Interaction,
        user: discord.Member,
        duration_minutes: int = None
    ):
        
        cargos_permitidos = [ADMIN_ROLE_ID, MOD_ROLE_ID, HEAD_ADMIN_ROLE_ID, HEAD_MOD_ROLE_ID, DEV_ROLE_ID,]
        if not any(role.id in cargos_permitidos for role in interaction.user.roles):
            await interaction.response.send_message("❌ You are not allowed.", ephemeral=True)
            return
        
        role = interaction.guild.get_role(BLACKLIST_ROLE_ID)
        if not role:
            return await interaction.response.send_message(
                "❌ Blacklist Role not found.",
                ephemeral=True
            )

        await user.add_roles(role, reason="Added to Ticket Blacklist")

        if duration_minutes:
            expires_at = datetime.utcnow() + timedelta(minutes=duration_minutes)
            collection.update_one(
                {"user_id": user.id},
                {"$set": {"expires_at": expires_at}},
                upsert=True
            )
            await interaction.response.send_message(
                f"✅ {user.mention} was added to the blacklist by {duration_minutes} minutes.",
                ephemeral=True
            )
        else:
            # Remove se existir no MongoDB, porque é tempo ilimitado
            collection.delete_one({"user_id": user.id})
            await interaction.response.send_message(
                f"✅ {user.mention} has been permanently blacklisted.",
                ephemeral=True
            )

    @app_commands.command(name="blacklist_remove", description="Removes a user from the blacklist.")
    @app_commands.describe(user="User to remove")
    async def blacklist_remove(
        self,
        interaction: discord.Interaction,
        user: discord.Member
    ):
        cargos_permitidos = [ADMIN_ROLE_ID, MOD_ROLE_ID, HEAD_ADMIN_ROLE_ID, HEAD_MOD_ROLE_ID, DEV_ROLE_ID]
        if not any(role.id in cargos_permitidos for role in interaction.user.roles):
            await interaction.response.send_message("❌ You are not allowed.", ephemeral=True)
            return

        role = interaction.guild.get_role(BLACKLIST_ROLE_ID)
        if role in user.roles:
            await user.remove_roles(role, reason="Removed from Ticket Blacklist")
            await interaction.response.send_message(
                f"✅ {user.mention} was removed from the blacklist.",
                ephemeral=True
            )
        else:
            await interaction.response.send_message(
                f"ℹ️ {user.mention} não está na blacklist (cargo não encontrado).",
                ephemeral=True
            )

        
            
    @app_commands.command(name="blacklist_check", description="Checks if a user is blacklisted.")
    @app_commands.describe(user="User to check")
    async def blacklist_check(
        self,
        interaction: discord.Interaction,
        user: discord.Member
    ):
        
        cargos_permitidos = [ADMIN_ROLE_ID, MOD_ROLE_ID, HEAD_ADMIN_ROLE_ID, HEAD_MOD_ROLE_ID, DEV_ROLE_ID,]
        if not any(role.id in cargos_permitidos for role in interaction.user.roles):
            await interaction.response.send_message("❌ You are not allowed.", ephemeral=True)
            return
        
        
        role = interaction.guild.get_role(BLACKLIST_ROLE_ID)
        if role in user.roles:
            doc = collection.find_one({"user_id": user.id})
            if doc and "expires_at" in doc:
                exp = doc["expires_at"].replace(tzinfo=timezone.utc).astimezone(UTC_MINUS_3)
                await interaction.response.send_message(
                    f"🚫 {user.mention} is on the blacklist until {exp.strftime('%d/%m/%Y %H:%M UTC-3')}.",
                    ephemeral=True
                )
            else:
                await interaction.response.send_message(
                    f"🚫 {user.mention} is permanently blacklisted.",
                    ephemeral=True
                )
        else:
            await interaction.response.send_message(
                f"✅ {user.mention} not on the blacklist.",
                ephemeral=True
            )

    @tasks.loop(minutes=1)
    async def check_blacklist_expirations(self):
        now = datetime.utcnow()
        expired = collection.find({"expires_at": {"$lte": now}})
        guilds = self.bot.guilds
        for entry in expired:
            user_id = entry["user_id"]
            for guild in guilds:
                member = guild.get_member(user_id)
                if member:
                    role = guild.get_role(BLACKLIST_ROLE_ID)
                    if role in member.roles:
                        await member.remove_roles(role, reason="Expired Blacklist")
                        print(f"✅ Automatically removed: {member} blacklist role.")
            collection.delete_one({"user_id": user_id})

    @check_blacklist_expirations.before_loop
    async def before_check_blacklist(self):
        await self.bot.wait_until_ready()


async def setup(bot):
    await bot.add_cog(Blacklist(bot))